local blips = {
    {
        title = "Polizei Station", -- Name of the location
        color = 3, -- Blip color (see GTA V blip colors)
        id = 60, -- Blip sprite (see GTA V blip sprites)
        x = 425.1, -- X coordinate
        y = -979.5, -- Y coordinate
        z = 30.7, -- Z coordinate
        scale = 1.0, -- Scale of the blip
    },
    {
        title = "Test",
        color = 2,
        id = 61,  
        x = 257.85,
        y = -867.12,
        z = 29.31,
        scale = 1.0,
    }
}

-- Function to create blips
Citizen.CreateThread(function()
    for _, info in pairs(blips) do
        local blip = AddBlipForCoord(info.x, info.y, info.z)
        SetBlipSprite(blip, info.id)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, info.scale)
        SetBlipColour(blip, info.color)
        SetBlipAsShortRange(blip, true)

        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(info.title)
        EndTextCommandSetBlipName(blip)
    end
end)


-- Blip ids: https://wiki.rage.mp/index.php?title=Blips
