fx_version 'cerulean'
game 'gta5'

author 'Lias82'
description 'Ein Script für benutzerdefinierte Blips'
version '1.0.0'

lua54 'yes'

client_script 'blips.lua'
