-- How to use the /addblip command:
-- /addblip [title] [x] [y] [z] [sprite_id] [color] [scale]
-- Example: /addblip CustomBlip 200.0 300.0 30.0 1 3 1.0



#### INSTALATION

- place `ll-blipcreator` in your resources folder
- add `ensure bcc-customblips` to your `resources.cfg`.
- restart server, enjoy.


